# rbMenuVIP
• Script de Menu VIP Optimisé et complet  
• Fonctionne avec Steam Hex  
• Framework: ESX  
• Lib utilisée: RageUI V2  

# Installation
• Mettre VIP dans votre dossier resources  
• Start la resource dans server.cfg

# https://discord.gg/fvREQYVAqR

SvS-devloppement
